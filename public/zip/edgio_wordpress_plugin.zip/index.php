<?php
/**
 * Plugin Name: Edgio
 * Plugin URI: https://edg.io
 * Description:
 * Version: 0.1.0
 * Author: Edgio Inc.
 * License: Proprietary
 */

if ( ! class_exists( 'Edgio_Site_Internals' ) ) {
	require_once dirname( __FILE__ ) . '/vendor/autoload.php';
}
global $wpsc_save_headers;
$wpsc_save_headers = true;

$edgioInternalsInstance = Edgio_Site_Internals::get_instance();

add_filter( 'wpsc_known_headers', [ $edgioInternalsInstance, 'filter_wpsc_known_headers' ], 10, 1 );

add_action( 'plugins_loaded', [ $edgioInternalsInstance, 'action_plugins_loaded' ], 10, 0 );

add_filter( 'wp_headers', [ $edgioInternalsInstance, 'filter_wp_headers' ], 10, 1 );
add_filter( 'nocache_headers', [ $edgioInternalsInstance, 'filter_nocache_headers' ], 10, 1 );

add_action( 'wp', [ $edgioInternalsInstance, 'action_wp' ], 10, 0 );

add_filter( 'the_posts', [ $edgioInternalsInstance, 'filter_the_posts' ], 10, 2 );

// Load Automatic Cache Purge
$edgioPurgeEverythingActions = array(
	'autoptimize_action_cachepurged',   // Compat with https://wordpress.org/plugins/autoptimize
	'switch_theme',                     // Switch theme
	'customize_save_after',              // Edit theme
	'wp_update_nav_menu',               // Edit menu
);

$edgioPurgeEverythingActions = apply_filters( 'edgio_purge_everything_actions', $edgioPurgeEverythingActions );

foreach ( $edgioPurgeEverythingActions as $action ) {
	add_action( $action, [ $edgioInternalsInstance, 'purgeCacheEverything' ], PHP_INT_MAX );
}

$edgioPurgeURLActions = array(
	'deleted_post',                     // Delete a post
	'delete_attachment',                // Delete an attachment - includes re-uploading
);

$edgioPurgeURLActions = apply_filters( 'edgio_purge_url_actions', $edgioPurgeURLActions );

foreach ( $edgioPurgeURLActions as $action ) {
	add_action( $action, array( $edgioInternalsInstance, 'purgeCacheForPostIds' ), PHP_INT_MAX );
}

/**
 * Register action to account for post status changes
 * This includes
 * - publish => publish transitions (editing a published post: no actual status change but the hook runs nevertheless)
 * - manually publishing/unpublishing a post
 * - WordPress automatically publishing a scheduled post at the appropriate time
 */
add_action( 'transition_post_status', array(
	$edgioInternalsInstance,
	'purgeCacheOnPostStatusChange'
), PHP_INT_MAX, 3 );

/**
 * Register two new actions which account for comment status before purging cache
 */
add_action( 'transition_comment_status', array(
	$edgioInternalsInstance,
	'purgeCacheOnCommentStatusChange'
), PHP_INT_MAX, 3 );
add_action( 'comment_post', array( $edgioInternalsInstance, 'purgeCacheOnNewComment' ), PHP_INT_MAX, 3 );

add_action( 'admin_notices', array( $edgioInternalsInstance, 'action_admin_notices' ), PHP_INT_MAX );

// Edgio Settings Page
function edgio_action_admin_menu() {
	add_options_page(
		'Edgio Settings',
		'Edgio',
		'manage_options',
		'edgio-settings',
		'edgio_page_content',
		'dashicons-admin-plugins',
		3
	);
}

add_action( 'admin_menu', 'edgio_action_admin_menu' );

define( 'EDGIO_PAGE_CONTENT_HOOK', "edgio_page_content" );

function edgio_page_content() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}

	$page_content = "
        <div class='wrap'>
			<h1>Edgio Settings</h1>
			<table class='form-table' role='presentation'>
				<tbody>
					<tr>
						<th scope='row'><label for='blogname'>Purge everything in cache</label></th>
						<td>
							<form action='/wp-admin/admin-post.php' method='post'>
								<input type='hidden' name='action' value='edgio_clear_cache'>
								<input id='edgio_clear_cache' type='submit' class='button button-primary' value='Clear cache'>
							</form>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	";
	$page_content = apply_filters( EDGIO_PAGE_CONTENT_HOOK, $page_content );
	echo $page_content;

	echo "<form method='POST' action='options.php'>";
	settings_fields( 'edgio-settings' );
	do_settings_sections( 'edgio-settings' );
	submit_button();
	echo "</form>";
}

add_action( 'admin_post_edgio_clear_cache', 'edgio_action_clear_cache' );

function edgio_action_clear_cache() {
	global $edgioInternalsInstance;
	$edgioInternalsInstance->purgeCacheEverything();

	wp_safe_redirect( '/wp-admin/options-general.php?page=edgio-settings' );

	die();
}

add_action( 'admin_init', 'edgio_action_admin_init' );

function edgio_action_admin_init() {

	add_settings_section(
		'edgio_page_setting_environment_section',
		'Environment settings',
		'edgio_action_admin_init_add_settings_section_callback',
		'edgio-settings'
	);

	add_settings_field(
		'edgio_environment_name',
		'Environment',
		'edgio_action_admin_init_end_callback',
		'edgio-settings',
		'edgio_page_setting_environment_section',
		array(
			'edgio_environment_name'
		)
	);

	add_settings_field(
		'edgio_api_key',
		'API Key',
		'edgio_action_admin_init_api_key_callback',
		'edgio-settings',
		'edgio_page_setting_environment_section',
		array(
			'edgio_api_key'
		)
	);

	add_settings_section(
		'edgio_page_setting_cache_section',
		'Cache settings',
		'edgio_action_admin_init_add_cache_settings_section_callback',
		'edgio-settings'
	);

	add_settings_field(
		'edgio_browser_cache_ttl',
		'Browser cache TTL – seconds',
		'edgio_action_admin_init_browser_cache_ttl_callback',
		'edgio-settings',
		'edgio_page_setting_cache_section',
		array(
			'edgio_browser_cache_ttl'
		)
	);

	add_settings_field(
		'edgio_edge_cache_ttl',
		'Edge cache TTL – seconds',
		'edgio_action_admin_init_edge_cache_ttl_callback',
		'edgio-settings',
		'edgio_page_setting_cache_section',
		array(
			'edgio_edge_cache_ttl'
		)
	);

	add_settings_field(
		'edgio_edge_cache_swr',
		'Cache Stale-While-Revalidate (SWR) – seconds',
		'edgio_action_admin_init_edge_cache_swr_callback',
		'edgio-settings',
		'edgio_page_setting_cache_section',
		array(
			'edgio_edge_cache_swr'
		)
	);

	register_setting( 'edgio-settings', 'edgio_environment_name', 'esc_attr' );
	register_setting( 'edgio-settings', 'edgio_api_key', 'esc_attr' );
	register_setting( 'edgio-settings', 'edgio_browser_cache_ttl', 'esc_attr' );
	register_setting( 'edgio-settings', 'edgio_edge_cache_ttl', 'esc_attr' );
	register_setting( 'edgio-settings', 'edgio_edge_cache_swr', 'esc_attr' );
}

function edgio_action_admin_init_add_settings_section_callback() {
	echo '<p>Edgio environment configuration for your website.</p>';
}
function edgio_action_admin_init_add_cache_settings_section_callback() {
	echo '<p>How would you like to cache the public content on this website?</p>';
}

function edgio_action_admin_init_end_callback() {
	$env = get_option( 'edgio_environment_name' );
	echo "<input type='text' id='edgio_environemt' name='edgio_environment_name' value='$env'>";
}

function edgio_action_admin_init_api_key_callback() {
	$api_key = get_option( 'edgio_api_key' );
	echo "<input type='text' id='edgio_api_key' autocomplete='off' name='edgio_api_key' value='$api_key'>";
}

function edgio_action_admin_init_edge_cache_ttl_callback() {
	$content = get_option( 'edgio_edge_cache_ttl', 3600 );
	echo "<input type='number' id='edgio_edge_cache_ttl' autocomplete='off' name='edgio_edge_cache_ttl' value='$content'>";
}

function edgio_action_admin_init_browser_cache_ttl_callback() {
	$content = get_option( 'edgio_browser_cache_ttl', 0 );
	echo "<input type='number' id='edgio_browser_cache_ttl' autocomplete='off' name='edgio_browser_cache_ttl' value='$content'>";
}

function edgio_action_admin_init_edge_cache_swr_callback() {
	$content = get_option( 'edgio_edge_cache_swr', 0 );
	echo "<input type='number' id='edgio_edge_cache_swr' autocomplete='off' name='edgio_edge_cache_swr' value='$content'>";
}

// Edgio uninstallation

register_uninstall_hook( __FILE__, 'edgio_register_uninstall_hook' );

function edgio_register_uninstall_hook() {
	delete_option( 'edgio_environment' );
	delete_option( 'edgio_api_key' );
}

