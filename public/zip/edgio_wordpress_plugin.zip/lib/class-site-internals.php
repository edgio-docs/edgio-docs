<?php

class Edgio_Site_Internals {
	private static $instance;
	private $environment_name;
	private $api_key;

	public $request_context = array();

	/**
	 *
	 * @return Edgio_Site_Internals
	 */
	public static function get_instance() {
		if ( ! self::$instance ) {
			$environment_name = get_option( 'edgio_environment_name' );
			$api_key          = get_option( 'edgio_api_key' );
			self::$instance   = new Edgio_Site_Internals( $environment_name, $api_key );
		}

		return self::$instance;
	}

	public function __construct( $environment_name, $api_key ) {
		$this->environment_name = $environment_name;
		$this->api_key          = $api_key;
	}

	public function purgeCacheForTags( array $tags ): bool {
		$endpoint = 'https://app.layer0.co/api/v1/clear-cache';

		$body = [
			'environment' => $this->environment_name,
		];

		if ( count( $tags ) > 0 ) {
			$body['surrogateKeys'] = $tags;
		}

		$body = wp_json_encode( $body );

		$options = [
			'body'    => $body,
			'headers' => [
				'Content-Type' => 'application/json',
				'x-api-key'    => $this->api_key,
			]
		];

		$response = wp_remote_post( $endpoint, $options );
		$apiBody  = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! empty( $apiBody['error'] ) ) {
			$this->notice( 'error', 'Edgio: Error while trying to purge cache: ' . $apiBody['error']['message'] );

			return false;
		}

		if ( ! $apiBody['success'] ) {
			$this->notice( 'error', 'Edgio: Unknown error while trying to purge cache' );

			return false;
		}

		$this->notice( 'success', 'Edgio: Cache purged successfully' );

		return ! ! $apiBody['success'];
	}

	/**
	 * @param $post_ids string[] | int
	 *
	 * @return bool
	 */
	public function purgeCacheForPostIds( $post_ids ): bool {
		$cacheTags = [];
		if ( ! is_array( $post_ids ) ) {
			$post_ids = [ $post_ids ];
		}
		foreach ( $post_ids as $postId ) {
			$relatedTags = $this->getSingularTagForAPost( $postId );
			$cacheTags   = array_merge( $cacheTags, $relatedTags );
		}
		if ( count( $cacheTags ) < 1 ) {
			return false;
		}

		return $this->purgeCacheForTags( $cacheTags );
	}

	/**
	 * @return void
	 */
	public function purgeCacheEverything(): bool {
		$this->notice( 'info', 'Edgio: Purging cache for everything' );

		return $this->purgeCacheForTags( [] );
	}

	public static function getSingularTagForAPost( $postId ): array {
		if ( ! $postId ) {
			return [];
		}

		if ( ! is_string( $postId ) && ! is_numeric( $postId ) ) {
			$postId = $postId->ID;
		}

		$cacheTags[] = 'post=' . $postId;

		return $cacheTags;
	}

	public static function getRelatedTagsForAPost( $postId ): array {
		if ( ! $postId ) {
			return [];
		}

		if ( ! is_string( $postId ) && ! is_numeric( $postId ) ) {
			$postId = $postId->ID;
		}

		$cacheTags[] = 'post=' . $postId;

		// Do not purge for autosaves or updates to post revisions.
		if ( wp_is_post_autosave( $postId ) || wp_is_post_revision( $postId ) ) {
			return $cacheTags;
		}

		$postType = get_post_type_object( get_post_type( $postId ) );
		if ( ! is_post_type_viewable( $postType ) ) {
			return $cacheTags;
		}

		$savedPost = get_post( $postId );
		if ( ! is_a( $savedPost, 'WP_Post' ) ) {
			return $cacheTags;
		}

		$taxonomies = get_post_taxonomies( $postId );

		foreach ( $taxonomies as $taxonomy ) {
			// Only if taxonomy is public
			$taxonomy_data = get_taxonomy( $taxonomy );
			if ( $taxonomy_data instanceof WP_Taxonomy && false === $taxonomy_data->public ) {
				continue;
			}

			$cacheTags[] = 'taxonomy=' . $taxonomy_data->name;

			$terms = get_the_terms( $postId, $taxonomy );

			if ( empty( $terms ) || is_wp_error( $terms ) ) {
				continue;
			}

			foreach ( $terms as $term ) {
				$cacheTags[] = 'term=' . $term->term_id;
			}
		}

		$cacheTags[] = 'author=' . get_post_field( 'post_author', $postId );

		return $cacheTags;
	}

	public function purgeCacheOnPostStatusChange( $new_status, $old_status, $post ) {
		if ( 'publish' === $new_status || 'publish' === $old_status ) {
			$this->purgeCacheForPostIds( [ $post->ID ] );
		}
	}

	public function purgeCacheOnCommentStatusChange( $new_status, $old_status, $comment ) {
		if ( ! isset( $comment->comment_post_ID ) || empty( $comment->comment_post_ID ) ) {
			return; // nothing to do
		}

		// in case the comment status changed, and either old or new status is "approved", we need to purge cache for the corresponding post
		if ( ( $old_status != $new_status ) && ( ( $old_status === 'approved' ) || ( $new_status === 'approved' ) ) ) {
			$this->purgeCacheForPostIds( [ $comment->comment_post_ID ] );

			return;
		}
	}

	public function purgeCacheOnNewComment( $comment_id, $comment_status, $comment_data ) {
		if ( $comment_status != 1 ) {
			return; // if comment is not approved, stop
		}
		if ( ! is_array( $comment_data ) ) {
			return; // nothing to do
		}
		if ( ! array_key_exists( 'comment_post_ID', $comment_data ) ) {
			return; // nothing to do
		}

		// all clear, we ne need to purge cache related to this post id
		$this->purgeCacheForPostIds( [ $comment_data['comment_post_ID'] ] );
	}

	public function action_plugins_loaded() {
		$this->request_context = [
			'tags'                          => [],
			'filter_nocache_headers_called' => false,
			'notices'                       => get_option( 'edgio_notices', [] ),
			'immediateNotices'              => [],
		];
		if ( empty( $this->environment_name ) ) {
			$this->immediateNotice( 'error', 'Edgio: Environment name is not set' );
		}
		if ( empty( $this->api_key ) ) {
			$this->immediateNotice( 'error', 'Edgio: API key is not set' );
		}
	}

	public function filter_wpsc_known_headers( $known_headers ) {
		$known_headers[] = 'x-0-surrogate-key';
		$known_headers[] = 'Surrogate-Key';

		return $known_headers;
	}

	public function notice( $level, $message, $transient = true ) {
		$notice                             = "<div class=\"notice notice-$level is-dismissible\"><p>$message</p></div>";
		$this->request_context['notices'][] = [
			'content'   => $notice,
			'transient' => $transient,
		];
		update_option( 'edgio_notices', $this->request_context['notices'], true );
	}

	public function immediateNotice( $level, $message ) {
		$notice                                      = "<div class=\"notice notice-$level is-dismissible\"><p>$message</p></div>";
		$this->request_context['immediateNotices'][] = [
			'content' => $notice,
		];
	}

	public function noticeClear( $content ) {
		foreach ( $this->request_context['notices'] as $index => $existingNotice ) {
			if ( $existingNotice['content'] == $content ) {
				unset( $this->request_context['notices'][ $index ] );
			}
		}
		update_option( 'edgio_notices', $this->request_context['notices'], true );
	}

	public function filter_nocache_headers( array $headers ): array {
		// add header unconditionally so we can detect plugin is activated
		$this->request_context['filter_nocache_headers_called'] = true;

		return $headers;
	}

	public function filter_wp_headers( array $headers ): array {
		// add header unconditionally so we can detect plugin is activated
		$cache = apply_filters( 'edgio_cache_response', ! is_user_logged_in() );
		if ( $cache && $this->request_context['filter_nocache_headers_called'] === false ) {
			$browser_cache_ttl    = intval( get_option( 'edgio_browser_cache_ttl', 0 ) );
			$edge_cache_ttl       = intval( get_option( 'edgio_edge_cache_ttl', 18000 ) );
			$edge_cache_swr       = intval( get_option( 'edgio_edge_cache_swr', 0 ) );
			$cache_control_header = [];
			if ( $browser_cache_ttl > - 1 ) {
				$cache_control_header[] = sprintf( "max-age=%d", $browser_cache_ttl );
			}
			if ( $edge_cache_ttl > - 1 ) {
				$cache_control_header[] = sprintf( "s-maxage=%d", $edge_cache_ttl );
			}
			if ( $edge_cache_swr > - 1 ) {
				$cache_control_header[] = sprintf( "stale-while-revalidate=%d", $edge_cache_swr );
			}
			$headers["cache-control"] = implode( ', ', $cache_control_header );
		}

		return $headers;
	}

	public function action_wp() {
		$this->request_context['tags'] = array_unique( $this->request_context['tags'] );

		header( 'x-0-surrogate-key: ' . implode( ' ', $this->request_context['tags'] ) );
		header( 'Surrogate-Key: ' . implode( ' ', $this->request_context['tags'] ) );
	}

	/**
	 * @param $num_posts
	 * @param $query WP_Query
	 *
	 * @return mixed
	 */
	public function filter_the_posts( $posts, $query ) {
		$postTags = [];
		foreach ( $posts as $post ) {
			$postTags = array_merge( $postTags, $this->getRelatedTagsForAPost( $post ) );
		}

		$postTags = array_unique( $postTags );

		$postTags = array_filter( $postTags, function ( $tag ) {
			return ! empty( explode( '=', $tag )[1] );
		} );

		$this->request_context['tags'] = array_merge( $this->request_context['tags'], $postTags );

		return $posts;
	}

	public function action_admin_notices() {
		foreach ( $this->request_context['notices'] as $notice ) {
			echo $notice['content'];
			if ( $notice['transient'] ) {
				$this->noticeClear( $notice['content'] );
			}
		}
		foreach ( $this->request_context['immediateNotices'] as $notice ) {
			echo $notice['content'];
		}
	}
}
